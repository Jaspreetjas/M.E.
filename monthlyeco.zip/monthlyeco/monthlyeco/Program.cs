﻿using System;
    class MonthlyEco
    {
        static void Main()
        {
        int messBill, khanaPeena, busFair, stationary, extras, totalKharcha, bakaya;

        string messBillString, khanaPeenaString, busFairString, stationaryString, extrasString;

        Console.WriteLine("Enter mess bill:");
        messBillString = Console.ReadLine();
        messBill = int.Parse(messBillString);

        Console.WriteLine("Enter khaan peen da kharcha:");
        khanaPeenaString = Console.ReadLine();
        khanaPeena = int.Parse(khanaPeenaString);

        Console.WriteLine("Enter bus fair:");
        busFairString = Console.ReadLine();
        busFair = int.Parse(busFairString);

        Console.WriteLine("Enter stationary expenses:");
        stationaryString = Console.ReadLine();
        stationary = int.Parse(stationaryString);

        Console.WriteLine("Enter extra expenses:");
        extrasString = Console.ReadLine();
        extras = int.Parse(extrasString);

        totalKharcha = messBill + khanaPeena + busFair + stationary + extras;

        Console.WriteLine("The total kharcha is:" + totalKharcha);

        bakaya = 2600 - totalKharcha;

        if(bakaya>0)
        {
            Console.WriteLine("The banefit is :" + bakaya);
        }

        if(bakaya<0)
        {
            Console.WriteLine("The loss is :" + bakaya);
        }
        Console.ReadLine();
    }
    }

